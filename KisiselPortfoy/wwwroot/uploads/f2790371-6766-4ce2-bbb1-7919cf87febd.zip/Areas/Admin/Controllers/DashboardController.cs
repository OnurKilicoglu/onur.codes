﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Basilico.Areas.Admin.Models;
using Basilico.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using System;
using Basilico.Models;
using Basilico.Data;

namespace Basilico.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Administrator")]
    public class DashboardController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DashboardController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            // Get counts for each entity type
            var menuItemsCount = await _context.MenuItems.CountAsync();
            var categoriesCount = await _context.MenuCategories.CountAsync();
            var blogPostsCount = await _context.BlogPosts.CountAsync();
            var galleryImagesCount = await _context.GalleryImages.CountAsync();
            var messageCount = await _context.ContactMessages.CountAsync();

            // Get recent messages
            var recentMessages = await _context.ContactMessages
                .OrderByDescending(m => m.Id)
                .Take(5)
                .ToListAsync();

            // Get popular menu items (based on whether they are marked as special)
            var popularMenuItems = await _context.MenuItems
                .Where(m => m.IsSpecial)
                .Include(m => m.Category)
                .Take(5)
                .ToListAsync();

            // Get recent blog posts
            var recentBlogPosts = await _context.BlogPosts
                .OrderByDescending(b => b.Id)
                .Take(3)
                .ToListAsync();

            var model = new DashboardViewModel
            {
                TotalMenuItems = menuItemsCount,
                TotalCategories = categoriesCount,
                TotalBlogPosts = blogPostsCount,
                TotalGalleryImages = galleryImagesCount,
                TotalContactMessages = messageCount,
                RecentMessages = recentMessages,
                PopularMenuItems = popularMenuItems,
                RecentBlogPosts = recentBlogPosts,
                LastUpdated = DateTime.Now
            };

            return View(model);
        }

        [HttpGet]
        public IActionResult SystemInfo()
        {
            var model = new SystemInfoViewModel
            {
                OperatingSystem = Environment.OSVersion.ToString(),
                MachineName = Environment.MachineName,
                AspNetVersion = Environment.Version.ToString(),
                ServerTime = DateTime.Now,
                ApplicationPath = Environment.CurrentDirectory,
                EnvironmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") ?? "Production"
            };

            return View(model);
        }
    }
}