﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Basilico.Areas.Admin.Models;
using Basilico.Data;
using Basilico.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Basilico.Areas.Admin.Models;
using Basilico.Data;
using Basilico.Models;

namespace Basilico.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Administrator")]
    public class GalleryController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GalleryController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Admin/Gallery
        public async Task<IActionResult> Index(string searchTerm, string category, int pageNumber = 1, int pageSize = 12)
        {
            var query = _context.GalleryImages.AsQueryable();

            // Apply search filter if provided
            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(g => g.Title.Contains(searchTerm) ||
                                        g.Description.Contains(searchTerm) ||
                                        g.Category.Contains(searchTerm));
            }

            // Apply category filter if provided
            if (!string.IsNullOrEmpty(category))
            {
                query = query.Where(g => g.Category == category);
            }

            // Get total count for pagination
            var totalCount = await query.CountAsync();

            // Apply pagination and ordering
            var images = await query
                .OrderByDescending(g => g.Id)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // Get all available categories for the filter dropdown
            var categories = await _context.GalleryImages
                .Select(g => g.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToListAsync();

            var model = new GalleryListViewModel
            {
                GalleryImages = images,
                SearchTerm = searchTerm,
                TotalCount = totalCount,
                CurrentPage = pageNumber,
                PageSize = pageSize
            };

            ViewBag.Categories = categories;
            ViewBag.SelectedCategory = category;

            return View(model);
        }

        // GET: Admin/Gallery/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var galleryImage = await _context.GalleryImages
                .FirstOrDefaultAsync(m => m.Id == id);

            if (galleryImage == null)
            {
                return NotFound();
            }

            return View(galleryImage);
        }

        // GET: Admin/Gallery/Create
        public IActionResult Create()
        {
            // Get all existing categories for dropdown
            var categories = _context.GalleryImages
                .Select(g => g.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToList();

            ViewBag.Categories = categories;

            return View();
        }

        // POST: Admin/Gallery/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(GalleryImage galleryImage)
        {
            if (ModelState.IsValid)
            {
                // Set creation date to current date if not provided
                if (galleryImage.DateAdded == default)
                {
                    galleryImage.DateAdded = DateTime.Now;
                }

                _context.Add(galleryImage);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Gallery image added successfully!";
                return RedirectToAction(nameof(Index));
            }

            // If we got this far, something failed, redisplay form
            var categories = _context.GalleryImages
                .Select(g => g.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToList();

            ViewBag.Categories = categories;

            return View(galleryImage);
        }

        // GET: Admin/Gallery/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var galleryImage = await _context.GalleryImages.FindAsync(id);
            if (galleryImage == null)
            {
                return NotFound();
            }

            // Get all existing categories for dropdown
            var categories = _context.GalleryImages
                .Select(g => g.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToList();

            ViewBag.Categories = categories;

            return View(galleryImage);
        }

        // POST: Admin/Gallery/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, GalleryImage galleryImage)
        {
            if (id != galleryImage.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(galleryImage);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Gallery image updated successfully!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GalleryImageExists(galleryImage.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            // If we got this far, something failed, redisplay form
            var categories = _context.GalleryImages
                .Select(g => g.Category)
                .Distinct()
                .OrderBy(c => c)
                .ToList();

            ViewBag.Categories = categories;

            return View(galleryImage);
        }

        // GET: Admin/Gallery/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var galleryImage = await _context.GalleryImages
                .FirstOrDefaultAsync(m => m.Id == id);

            if (galleryImage == null)
            {
                return NotFound();
            }

            return View(galleryImage);
        }

        // POST: Admin/Gallery/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var galleryImage = await _context.GalleryImages.FindAsync(id);
            _context.GalleryImages.Remove(galleryImage);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Gallery image deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        // POST: Admin/Gallery/DeleteMultiple
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteMultiple(int[] selectedIds)
        {
            if (selectedIds == null || selectedIds.Length == 0)
            {
                TempData["ErrorMessage"] = "No images selected for deletion.";
                return RedirectToAction(nameof(Index));
            }

            var images = await _context.GalleryImages
                .Where(g => selectedIds.Contains(g.Id))
                .ToListAsync();

            _context.GalleryImages.RemoveRange(images);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"{images.Count} image(s) deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Admin/Gallery/Categories
        public async Task<IActionResult> Categories()
        {
            var categories = await _context.GalleryImages
                .GroupBy(g => g.Category)
                .Select(g => new {
                    Category = g.Key,
                    Count = g.Count()
                })
                .OrderBy(g => g.Category)
                .ToListAsync();

            return View(categories);
        }

        private bool GalleryImageExists(int id)
        {
            return _context.GalleryImages.Any(e => e.Id == id);
        }
    }
}