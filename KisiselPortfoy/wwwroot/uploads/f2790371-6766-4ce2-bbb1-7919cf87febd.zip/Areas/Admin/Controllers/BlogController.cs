﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Basilico.Areas.Admin.Models;
using Basilico.Data;
// Using direct reference
using Basilico.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Basilico.Data;

namespace Basilico.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Administrator")]
    public class BlogController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BlogController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Admin/Blog
        public async Task<IActionResult> Index(string searchTerm, int pageNumber = 1, int pageSize = 10)
        {
            var query = _context.BlogPosts.AsQueryable();

            // Apply search filter if provided
            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(b => b.Title.Contains(searchTerm) ||
                                        b.Content.Contains(searchTerm));
            }

            // Get total count for pagination
            var totalCount = await query.CountAsync();

            // Apply pagination
            var posts = await query
                .OrderByDescending(b => b.Date)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var model = new BlogPostListViewModel
            {
                BlogPosts = posts,
                SearchTerm = searchTerm,
                TotalCount = totalCount,
                CurrentPage = pageNumber,
                PageSize = pageSize
            };

            return View(model);
        }

        // GET: Admin/Blog/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blogPost = await _context.BlogPosts
                .FirstOrDefaultAsync(m => m.Id == id);

            if (blogPost == null)
            {
                return NotFound();
            }

            return View(blogPost);
        }

        // GET: Admin/Blog/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Admin/Blog/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(BlogPost blogPost)
        {
            if (ModelState.IsValid)
            {
                // Set creation date to current date if not provided
                if (blogPost.Date == default)
                {
                    blogPost.Date = DateTime.Now;
                }

                // Generate slug from title if not provided
                if (string.IsNullOrEmpty(blogPost.Slug))
                {
                    blogPost.Slug = GenerateSlug(blogPost.Title);
                }

                _context.Add(blogPost);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = "Blog post created successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(blogPost);
        }

        // GET: Admin/Blog/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blogPost = await _context.BlogPosts.FindAsync(id);
            if (blogPost == null)
            {
                return NotFound();
            }
            return View(blogPost);
        }

        // POST: Admin/Blog/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, BlogPost blogPost)
        {
            if (id != blogPost.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Generate slug from title if not provided
                    if (string.IsNullOrEmpty(blogPost.Slug))
                    {
                        blogPost.Slug = GenerateSlug(blogPost.Title);
                    }

                    _context.Update(blogPost);
                    await _context.SaveChangesAsync();
                    TempData["SuccessMessage"] = "Blog post updated successfully!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BlogPostExists(blogPost.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(blogPost);
        }

        // GET: Admin/Blog/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var blogPost = await _context.BlogPosts
                .FirstOrDefaultAsync(m => m.Id == id);

            if (blogPost == null)
            {
                return NotFound();
            }

            return View(blogPost);
        }

        // POST: Admin/Blog/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var blogPost = await _context.BlogPosts.FindAsync(id);
            _context.BlogPosts.Remove(blogPost);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Blog post deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Admin/Blog/Comments
        public async Task<IActionResult> Comments(int? postId)
        {
            if (postId.HasValue)
            {
                var comments = await _context.Comments
                    .Where(c => c.BlogPostId == postId)
                    .OrderByDescending(c => c.Date)
                    .ToListAsync();

                ViewBag.BlogPost = await _context.BlogPosts.FindAsync(postId);
                return View(comments);
            }
            else
            {
                var comments = await _context.Comments
                    .OrderByDescending(c => c.Date)
                    .ToListAsync();

                return View(comments);
            }
        }

        // POST: Admin/Blog/ApproveComment/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveComment(int id)
        {
            var comment = await _context.Comments.FindAsync(id);
            if (comment == null)
            {
                return NotFound();
            }

            comment.IsApproved = true;
            _context.Update(comment);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Comment approved successfully!";
            return RedirectToAction(nameof(Comments), new { postId = comment.BlogPostId });
        }

        // POST: Admin/Blog/DeleteComment/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteComment(int id)
        {
            var comment = await _context.Comments.FindAsync(id);
            if (comment == null)
            {
                return NotFound();
            }

            int? postId = comment.BlogPostId;
            _context.Comments.Remove(comment);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Comment deleted successfully!";
            return RedirectToAction(nameof(Comments), new { postId });
        }

        private bool BlogPostExists(int id)
        {
            return _context.BlogPosts.Any(e => e.Id == id);
        }

        private string GenerateSlug(string title)
        {
            // Basic slug generator
            if (string.IsNullOrEmpty(title))
                return "";

            var slug = title.ToLower()
                .Replace(" ", "-")
                .Replace("&", "and")
                .Replace("?", "")
                .Replace("!", "")
                .Replace(".", "")
                .Replace(",", "")
                .Replace(":", "")
                .Replace(";", "")
                .Replace("'", "")
                .Replace("\"", "")
                .Replace("(", "")
                .Replace(")", "")
                .Replace("[", "")
                .Replace("]", "")
                .Replace("{", "")
                .Replace("}", "");

            // Check if slug exists and make it unique if needed
            var existingSlugs = _context.BlogPosts
                .Where(p => p.Slug.StartsWith(slug))
                .Select(p => p.Slug)
                .ToList();

            if (existingSlugs.Any())
            {
                int counter = 1;
                string newSlug = slug;

                while (existingSlugs.Contains(newSlug))
                {
                    newSlug = $"{slug}-{counter}";
                    counter++;
                }

                slug = newSlug;
            }

            return slug;
        }
    }
}