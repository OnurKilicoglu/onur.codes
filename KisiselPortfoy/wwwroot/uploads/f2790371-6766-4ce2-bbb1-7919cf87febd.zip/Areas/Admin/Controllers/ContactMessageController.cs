﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Basilico.Areas.Admin.Models;
using Basilico.Data;
using Basilico.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Basilico.Areas.Admin.Models;
using Basilico.Data;

namespace Basilico.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = "Administrator")]
    public class ContactMessagesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ContactMessagesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Admin/ContactMessages
        public async Task<IActionResult> Index(string searchTerm, bool? isRead, int pageNumber = 1, int pageSize = 10)
        {
            var query = _context.ContactMessages.AsQueryable();

            // Apply search filter if provided
            if (!string.IsNullOrEmpty(searchTerm))
            {
                query = query.Where(m => m.Name.Contains(searchTerm) ||
                                        m.Email.Contains(searchTerm) ||
                                        m.Message.Contains(searchTerm) ||
                                        m.Subject.Contains(searchTerm));
            }

            // Apply read status filter if provided
            if (isRead.HasValue)
            {
                query = query.Where(m => m.IsRead == isRead.Value);
            }

            // Get total count for pagination
            var totalCount = await query.CountAsync();

            // Apply pagination and ordering
            var messages = await query
                .OrderByDescending(m => m.Id) // Assuming Id is auto-incrementing
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var model = new ContactMessageListViewModel
            {
                Messages = messages,
                SearchTerm = searchTerm,
                IsRead = isRead,
                TotalCount = totalCount,
                CurrentPage = pageNumber,
                PageSize = pageSize
            };

            return View(model);
        }

        // GET: Admin/ContactMessages/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var message = await _context.ContactMessages
                .FirstOrDefaultAsync(m => m.Id == id);

            if (message == null)
            {
                return NotFound();
            }

            // Mark as read if not already
            if (!message.IsRead)
            {
                message.IsRead = true;
                _context.Update(message);
                await _context.SaveChangesAsync();
            }

            return View(message);
        }

        // POST: Admin/ContactMessages/MarkAsRead/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkAsRead(int id)
        {
            var message = await _context.ContactMessages.FindAsync(id);
            if (message == null)
            {
                return NotFound();
            }

            message.IsRead = true;
            _context.Update(message);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Message marked as read successfully!";
            return RedirectToAction(nameof(Index));
        }

        // POST: Admin/ContactMessages/MarkAsUnread/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkAsUnread(int id)
        {
            var message = await _context.ContactMessages.FindAsync(id);
            if (message == null)
            {
                return NotFound();
            }

            message.IsRead = false;
            _context.Update(message);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = "Message marked as unread successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Admin/ContactMessages/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var message = await _context.ContactMessages
                .FirstOrDefaultAsync(m => m.Id == id);

            if (message == null)
            {
                return NotFound();
            }

            return View(message);
        }

        // POST: Admin/ContactMessages/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var message = await _context.ContactMessages.FindAsync(id);
            _context.ContactMessages.Remove(message);
            await _context.SaveChangesAsync();
            TempData["SuccessMessage"] = "Message deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        // POST: Admin/ContactMessages/DeleteMultiple
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteMultiple(int[] selectedIds)
        {
            if (selectedIds == null || selectedIds.Length == 0)
            {
                TempData["ErrorMessage"] = "No messages selected for deletion.";
                return RedirectToAction(nameof(Index));
            }

            var messages = await _context.ContactMessages
                .Where(m => selectedIds.Contains(m.Id))
                .ToListAsync();

            _context.ContactMessages.RemoveRange(messages);
            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"{messages.Count} message(s) deleted successfully!";
            return RedirectToAction(nameof(Index));
        }

        // POST: Admin/ContactMessages/MarkMultipleAsRead
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkMultipleAsRead(int[] selectedIds)
        {
            if (selectedIds == null || selectedIds.Length == 0)
            {
                TempData["ErrorMessage"] = "No messages selected.";
                return RedirectToAction(nameof(Index));
            }

            var messages = await _context.ContactMessages
                .Where(m => selectedIds.Contains(m.Id))
                .ToListAsync();

            foreach (var message in messages)
            {
                message.IsRead = true;
            }

            await _context.SaveChangesAsync();

            TempData["SuccessMessage"] = $"{messages.Count} message(s) marked as read successfully!";
            return RedirectToAction(nameof(Index));
        }
    }
}