using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basilico.Areas.Shared
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
