﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System;
using Basilico.Models;

namespace Basilico.Areas.Admin.Models
{
    public class DashboardViewModel
    {
        public int TotalMenuItems { get; set; }
        public int TotalCategories { get; set; }
        public int TotalBlogPosts { get; set; }
        public string AuthorName { get; set; }
        public int TotalGalleryImages { get; set; }
        public int TotalContactMessages { get; set; }
        public List<ContactMessage> RecentMessages { get; set; }
        public List<MenuItemDetail> PopularMenuItems { get; set; }
        public List<BlogPost> RecentBlogPosts { get; set; }
        public DateTime LastUpdated { get; set; }
    }

    public class SystemInfoViewModel
    {
        public string OperatingSystem { get; set; }
        public string MachineName { get; set; }
        public string AspNetVersion { get; set; }
        public DateTime ServerTime { get; set; }
        public string ApplicationPath { get; set; }
        public string EnvironmentName { get; set; }
    }

    public class LoginViewModel
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "Remember me?")]
        public bool RememberMe { get; set; }
    }

    public class MenuItemListViewModel
    {
        public List<MenuItemDetail> MenuItems { get; set; }
        public List<MenuCategory> Categories { get; set; }
        public string SearchTerm { get; set; }
        public int? CategoryFilter { get; set; }
    }

    public class BlogPostListViewModel
    {
        public List<BlogPost> BlogPosts { get; set; }
        public string SearchTerm { get; set; }
        public int TotalCount { get; set; }
        public int CurrentPage { get; set; }
        public int PageSize { get; set; }

        public int TotalPages
        {
            get
            {
                if (PageSize == 0) return 0;
                var totalPages = (int)Math.Ceiling((double)TotalCount / PageSize);
                return totalPages;
            }
        }
    }

    public class GalleryListViewModel
    {
        public List<GalleryImage> GalleryImages { get; set; }
        public string SearchTerm { get; set; }
        public int TotalCount { get; set; }
        public int CurrentPage { get; set; }
        public int PageSize { get; set; }

        public int TotalPages
        {
            get
            {
                if (PageSize == 0) return 0;
                var totalPages = (int)Math.Ceiling((double)TotalCount / PageSize);
                return totalPages;
            }
        }
    }

    public class ContactMessageListViewModel
    {
        public List<ContactMessage> Messages { get; set; }
        public string SearchTerm { get; set; }
        public bool? IsRead { get; set; }
        public int TotalCount { get; set; }
        public int CurrentPage { get; set; }
        public int PageSize { get; set; }

        public int TotalPages
        {
            get
            {
                if (PageSize == 0) return 0;
                var totalPages = (int)Math.Ceiling((double)TotalCount / PageSize);
                return totalPages;
            }
        }
    }

    public class StatisticsViewModel
    {
        public int DailyVisitors { get; set; }
        public int MonthlyVisitors { get; set; }
        public int TotalVisitors { get; set; }
        public Dictionary<string, int> PageViews { get; set; }
        public Dictionary<string, int> BrowserStats { get; set; }
        public Dictionary<string, int> DeviceStats { get; set; }
    }
}