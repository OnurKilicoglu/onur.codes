using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basilico.Areas.Views
{
    public class DeleteCategoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
