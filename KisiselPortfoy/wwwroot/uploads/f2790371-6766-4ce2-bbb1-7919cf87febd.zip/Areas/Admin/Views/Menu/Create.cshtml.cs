using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basilico.Areas.Views.Menu
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
