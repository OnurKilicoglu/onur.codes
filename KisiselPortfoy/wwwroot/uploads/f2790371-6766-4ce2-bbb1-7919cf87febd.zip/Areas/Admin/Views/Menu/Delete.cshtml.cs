using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basilico.Areas.Views.Menu
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
