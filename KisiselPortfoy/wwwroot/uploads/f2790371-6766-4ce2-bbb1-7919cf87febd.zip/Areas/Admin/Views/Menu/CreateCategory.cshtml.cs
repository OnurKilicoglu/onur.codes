using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basilico.Areas.Views.Menu
{
    public class CreateCategoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
