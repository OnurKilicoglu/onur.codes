using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Basilico.Areas.Views.Menu
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
